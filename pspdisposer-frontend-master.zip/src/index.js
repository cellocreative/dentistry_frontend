import React from 'react';
import { render } from 'react-dom';
import { usePromiseTracker } from "react-promise-tracker";
import App from './App';
import './style/frameworks.css';
import './style/softx.css'
import * as serviceWorker from './serviceWorker';


const LoadingIndicator = props => {
    const { promiseInProgress } = usePromiseTracker();
    return (
        promiseInProgress &&
        <div id="loading">
            <img id="loading-image" src={require("./assets/icons/loading.gif")} alt="Loading..." />
        </div>
    );  
}


render(

    <div style={{height: '100%'}}>
        <App />
        <LoadingIndicator />
    </div>, 
    document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.register();
